class Open_account:
    __account = ""
    __username = ""
    __passwprd = ""
    __country = ""
    __province = ""
    __street = ""
    __door = ""
    __money = 0
    __bank_name = "中国工商银行昌平支行"

    def setAccount(self,account):
        self.__account = account
    def getAccount(self):
        return self.__account

    def setUserame(self,username):
        self.__username = username
    def getUsername(self):
        return self.__username

    def setPassword(self,password):
        self.__passwprd = password
    def getPassword(self):
        return self.__passwprd

    def setCountry(self,country):
        self.__country = country
    def getCountry(self):
        return self.__country

    def setProvince(self,province):
        self.__province = province
    def getProvince(self):
        return self.__province

    def setStreet(self,street):
        self.__street = street
    def getStreet(self):
        return self.__street

    def setDoor(self,door):
        self.__door = door
    def getDoor(self):
        return self.__door

    def setMoney(self,money):
        self.__money = money
    def getMoney(self):
        return self.__money

    def getBank_Name(self):
        return self.__bank_name
