import random
from DBUtlis import update
from DBUtlis import select
# from main import Index
from ACCOUNT import Open_account

class Bank:
    myinfo = '''
        \033[0;32;40m
        ------------账户信息------------
        账号：{account}
        姓名：{username}
        密码：{password}
        地址：
            国家：{country}
            省份：{province}
            街道：{street}
            门牌号：{door}
        账户余额：{money}
        注册银行名：{bank_name}
        -------------------------------
        \033[0m
    '''

    def isExists(self,chose, data):
        if chose in data:
            return True
        return False

    # 获取随机码
    def getRandom(self):
        li = "0123456789qwertyuiopasdfghjklzxcvbnmZXCVBNMASDFGHJKLQWERTYUIOP"
        string = ""
        for i in range(8):
            string = string + li[int(random.random() * len(li))]
        return string


    def bank_addUser(self,username, password, country, province, street, door, money):
        # 查询是否已满
        sql = "select count(*) from bank"
        param = []
        data = select(sql, param)
        if len(data) >= 100:
            return 3

        # 查询是否存在
        sql1 = "select * from bank where username = %s"
        param1 = [username]
        data = select(sql1, param1)
        if len(data) != 0:
            return 2
        # 插入数据
        sql2 = "insert into bank value(%s,%s,%s,%s,%s,%s,%s,%s,now(),%s)"
        param2 = [self.getRandom(), username, password, country, province, street, door, money, Open_account().getBank_Name()]
        update(sql2, param2)
        return 1

    def bank_saveMoney(self,ac, money):
        sql = "select * from bank where account = %s"
        param = [ac]
        data = select(sql, param)
        if data != None and len(data) != 0:
            sql1 = "update bank set money = money + %s where account = %s"
            param = [money, ac]
            update(sql1, param)
            return True
        else:
            return False

    # 银行的查询功能
    def bank_selectUser(self,account, password):
        sql = "select * from bank where account = %s"
        param = [account]
        data = select(sql, param)
        if data != None and len(data) != 0:
            if password == data[0][2]:
                print(Bank().myinfo.format(account=data[0][0],
                                    username=data[0][1],
                                    password=data[0][2],
                                    country=data[0][3],
                                    province=data[0][4],
                                    street=data[0][5],
                                    door=data[0][6],
                                    money=data[0][7],
                                    bank_name=data[0][9]
                                    ))
            else:
                print("用户密码错误！")
        else:
            print("该用户不存在！")

    # 银行的取钱功能
    def bank_takeMoney(self,account, password, money):
        sql = "select * from bank where account = %s"
        param = [account]
        data = select(sql, param)
        if data != None and len(data) != 0:
            if data[0][2] == password:
                if data[0][7] < money:
                    return 3
                else:
                    sql1 = "update bank set money = money - %s where account = %s"
                    param1 = [money, account]
                    update(sql1, param1)
                    return 0
            else:
                return 2
        else:
            return 1

    # 银行的转账功能
    def bank_transformMoney(self,outputaccount, inputaccount, outputpassword, outputmoney):
        status = self.bank_takeMoney(outputaccount, outputpassword, outputmoney)
        if status == 1:
            return status
        elif status == 2:
            return status
        elif status == 3:
            return status

        sql = "select * from bank where account = %s"
        param = [inputaccount]
        FA = select(sql,param)
        if inputaccount != None and FA != None:
            self.bank_saveMoney(inputaccount, outputmoney)
            return 0
        else:
            return 1














